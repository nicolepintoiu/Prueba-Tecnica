--
-- PostgreSQL database dump
--

\restrict jd2Dhl7OAJL9GBrTZubyuCuI1dgUVzao0oFjIPFDandm7kHdhgEZYD1GvM9LyUz

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: prueba; Type: SCHEMA; Schema: -; Owner: prueba_user
--

CREATE SCHEMA prueba;


ALTER SCHEMA prueba OWNER TO prueba_user;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Contact; Type: TABLE; Schema: prueba; Owner: prueba_user
--

CREATE TABLE prueba."Contact" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    balance numeric(65,30) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE prueba."Contact" OWNER TO prueba_user;

--
-- Name: Operation; Type: TABLE; Schema: prueba; Owner: prueba_user
--

CREATE TABLE prueba."Operation" (
    id text NOT NULL,
    "contactId" text NOT NULL,
    amount numeric(65,30) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE prueba."Operation" OWNER TO prueba_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: prueba; Owner: prueba_user
--

CREATE TABLE prueba._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE prueba._prisma_migrations OWNER TO prueba_user;

--
-- Name: Contact; Type: TABLE; Schema: public; Owner: prueba_user
--

CREATE TABLE public."Contact" (
    id text NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    balance numeric(65,30) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Contact" OWNER TO prueba_user;

--
-- Name: Operation; Type: TABLE; Schema: public; Owner: prueba_user
--

CREATE TABLE public."Operation" (
    id text NOT NULL,
    "contactId" text NOT NULL,
    amount numeric(65,30) NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Operation" OWNER TO prueba_user;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: prueba_user
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO prueba_user;

--
-- Data for Name: Contact; Type: TABLE DATA; Schema: prueba; Owner: prueba_user
--

COPY prueba."Contact" (id, email, name, balance, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Operation; Type: TABLE DATA; Schema: prueba; Owner: prueba_user
--

COPY prueba."Operation" (id, "contactId", amount, "createdAt") FROM stdin;
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: prueba; Owner: prueba_user
--

COPY prueba._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
6ee66a33-babd-4233-998b-6428d9823a65	4da07047f117d266df5868a6e6026a05988ce19f81d2ba19bbb85f3ca80629e6	2026-01-16 16:26:21.330239-04	20260116202621_init	\N	\N	2026-01-16 16:26:21.326185-04	1
\.


--
-- Data for Name: Contact; Type: TABLE DATA; Schema: public; Owner: prueba_user
--

COPY public."Contact" (id, email, name, balance, "createdAt", "updatedAt") FROM stdin;
ca9f60d9-bf15-4096-9bca-8f36437ed94c	test@mail.com	Test User	0.000000000000000000000000000000	2026-01-16 21:27:58.269	2026-01-16 21:27:58.269
bcce5931-aced-4bf3-ab07-e7aa284bfcb4	a@a.com	Ana	0.000000000000000000000000000000	2026-01-16 22:23:58.381	2026-01-16 22:23:58.381
8478cc53-df32-46e7-a7b0-ab7801e757c8	csvtest@mail.com	CSV Test	0.000000000000000000000000000000	2026-01-19 18:45:30.367	2026-01-19 18:45:30.367
bfb0ee34-056a-4240-a7b4-983d76f5b6c0	csvtest_999@mail.com	CSV Test	5.000000000000000000000000000000	2026-01-19 19:09:23.934	2026-01-19 19:10:01.483
c00bcb4a-1424-431e-90d1-e21c4650be6c	carlos.new@test.com	Carlos Perez	193.000000000000000000000000000000	2026-01-19 22:36:58.899	2026-01-21 04:27:21.855
21c8fcbd-921c-4ebb-8133-25f9f8250459	ana@test.com	Ana	15.000000000000000000000000000000	2026-01-19 22:34:08.228	2026-01-21 15:10:13.821
07f663cb-5a55-4498-9c6a-2e6a7c5f7a9b	nicole@gmail.com	Nicole Pinto	20.000000000000000000000000000000	2026-01-21 04:28:25.283	2026-01-21 15:11:36.24
c0635132-048a-491a-8d98-b8e59e2f5bc5	optest@mail.com	Mario	10.000000000000000000000000000000	2026-01-16 22:33:42.098	2026-01-22 02:36:10.019
ee51c123-a457-4bf0-8a19-23b1c0f2a06b	optest2@mail.com	Carlos	15.000000000000000000000000000000	2026-01-16 22:45:23.198	2026-01-22 02:36:18.707
87b973f5-0064-4c75-84ab-c64be5cdb881	resta_test_1@mail.com	Maria	15.000000000000000000000000000000	2026-01-16 22:59:05.289	2026-01-22 02:36:26.907
73cf6277-fe1d-4013-9d6d-acbe421dcc53	rangotest_99@mail.com	Carla	5.000000000000000000000000000000	2026-01-19 18:59:23.145	2026-01-22 02:36:36.898
08f09c6c-f283-428b-9829-a503bc5a2fb3	csvtest2@mail.com	Sebastian	5.000000000000000000000000000000	2026-01-19 18:49:29.277	2026-01-22 02:36:51.319
\.


--
-- Data for Name: Operation; Type: TABLE DATA; Schema: public; Owner: prueba_user
--

COPY public."Operation" (id, "contactId", amount, "createdAt") FROM stdin;
9b4bb79c-097f-41f2-ac17-ba3fd8996414	c0635132-048a-491a-8d98-b8e59e2f5bc5	10.000000000000000000000000000000	2026-01-16 22:38:40.332
18516721-890f-47e2-9cc0-553f09d38488	ee51c123-a457-4bf0-8a19-23b1c0f2a06b	10.000000000000000000000000000000	2026-01-16 22:53:14.331
25b3244b-2ae3-446a-8e98-0cd06251f32b	ee51c123-a457-4bf0-8a19-23b1c0f2a06b	10.000000000000000000000000000000	2026-01-16 22:56:28.398
02fd4b7e-63d5-4221-a487-f65281e26197	ee51c123-a457-4bf0-8a19-23b1c0f2a06b	-5.000000000000000000000000000000	2026-01-16 22:57:06.968
365bcde9-f581-4044-a45b-dc347dd38b1e	87b973f5-0064-4c75-84ab-c64be5cdb881	10.000000000000000000000000000000	2026-01-16 23:00:11.665
6abb886d-c094-4159-a175-b0686e829fa8	87b973f5-0064-4c75-84ab-c64be5cdb881	-5.000000000000000000000000000000	2026-01-16 23:00:21.964
3560931d-5b2e-48d1-92c2-fe7baa66b43f	87b973f5-0064-4c75-84ab-c64be5cdb881	10.000000000000000000000000000000	2026-01-19 18:09:18.026
02ad9b6b-c552-41b0-9da8-84a76f4d3133	87b973f5-0064-4c75-84ab-c64be5cdb881	-5.000000000000000000000000000000	2026-01-19 18:09:26.597
d278c4f0-0103-4fff-a60c-c7a0779b893b	87b973f5-0064-4c75-84ab-c64be5cdb881	10.000000000000000000000000000000	2026-01-19 18:11:34.225
fc4a4a21-4bae-4a91-be57-fa2779628119	87b973f5-0064-4c75-84ab-c64be5cdb881	-5.000000000000000000000000000000	2026-01-19 18:11:39.78
60480cdd-204a-4f21-9083-c2d3a50e1492	08f09c6c-f283-428b-9829-a503bc5a2fb3	10.000000000000000000000000000000	2026-01-19 18:50:01.488
f6f3aeb0-9393-400c-a582-60fe5b40ae21	08f09c6c-f283-428b-9829-a503bc5a2fb3	-5.000000000000000000000000000000	2026-01-19 18:50:11.512
c7c236ce-6ed9-4e05-b989-1aca31915500	73cf6277-fe1d-4013-9d6d-acbe421dcc53	10.000000000000000000000000000000	2026-01-19 18:59:45.015
b060987c-9d20-47a2-8b01-5454f88d0c1e	73cf6277-fe1d-4013-9d6d-acbe421dcc53	-5.000000000000000000000000000000	2026-01-19 18:59:53.245
bf524900-9307-4b1a-8839-79d31347854e	bfb0ee34-056a-4240-a7b4-983d76f5b6c0	10.000000000000000000000000000000	2026-01-19 19:09:56.629
8678d3da-5a06-4acc-98f3-8af4266ae9b8	bfb0ee34-056a-4240-a7b4-983d76f5b6c0	-5.000000000000000000000000000000	2026-01-19 19:10:01.48
2a28130d-ae6c-47d7-99b5-c40240b344b9	c00bcb4a-1424-431e-90d1-e21c4650be6c	20.000000000000000000000000000000	2026-01-19 22:37:42.6
28ea2baf-6762-4174-b39b-497bac5b60b6	c00bcb4a-1424-431e-90d1-e21c4650be6c	-7.000000000000000000000000000000	2026-01-19 22:37:58.303
691fdc9e-b181-48a1-9473-b2d0a502867c	c00bcb4a-1424-431e-90d1-e21c4650be6c	20.000000000000000000000000000000	2026-01-21 04:20:47.973
ab187b14-c608-4435-a35c-430a94e89c48	c00bcb4a-1424-431e-90d1-e21c4650be6c	60.000000000000000000000000000000	2026-01-21 04:21:04.763
27a5386e-1461-4864-bb9b-5ca51689a7ca	c00bcb4a-1424-431e-90d1-e21c4650be6c	100.000000000000000000000000000000	2026-01-21 04:27:21.85
21b373c2-d58e-45f3-b66f-4a432482994b	07f663cb-5a55-4498-9c6a-2e6a7c5f7a9b	10.000000000000000000000000000000	2026-01-21 14:51:11.952
972e1939-40eb-455c-879e-66f4213693e8	07f663cb-5a55-4498-9c6a-2e6a7c5f7a9b	-5.000000000000000000000000000000	2026-01-21 14:53:18.151
2def26fa-f423-43e8-aa6c-5b02352cb137	07f663cb-5a55-4498-9c6a-2e6a7c5f7a9b	5.000000000000000000000000000000	2026-01-21 14:56:39.288
e61b5317-c32b-498a-888e-1fb9eb1d5e51	07f663cb-5a55-4498-9c6a-2e6a7c5f7a9b	5.000000000000000000000000000000	2026-01-21 14:57:20.172
f2d21029-d239-4eb2-9bca-c171a55f8469	07f663cb-5a55-4498-9c6a-2e6a7c5f7a9b	5.000000000000000000000000000000	2026-01-21 14:58:26.381
815e77db-7c87-4520-b107-fca51de63ef4	21c8fcbd-921c-4ebb-8133-25f9f8250459	10.000000000000000000000000000000	2026-01-21 15:09:50.925
54d38b1f-8a62-461c-ad98-f5d8c21837a8	21c8fcbd-921c-4ebb-8133-25f9f8250459	5.000000000000000000000000000000	2026-01-21 15:10:13.817
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: prueba_user
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
ec9f774c-0742-466c-8052-af455fc877dd	4da07047f117d266df5868a6e6026a05988ce19f81d2ba19bbb85f3ca80629e6	2026-01-16 17:27:39.043947-04	20260116202621_init	\N	\N	2026-01-16 17:27:39.037173-04	1
\.


--
-- Name: Contact Contact_pkey; Type: CONSTRAINT; Schema: prueba; Owner: prueba_user
--

ALTER TABLE ONLY prueba."Contact"
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY (id);


--
-- Name: Operation Operation_pkey; Type: CONSTRAINT; Schema: prueba; Owner: prueba_user
--

ALTER TABLE ONLY prueba."Operation"
    ADD CONSTRAINT "Operation_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: prueba; Owner: prueba_user
--

ALTER TABLE ONLY prueba._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Contact Contact_pkey; Type: CONSTRAINT; Schema: public; Owner: prueba_user
--

ALTER TABLE ONLY public."Contact"
    ADD CONSTRAINT "Contact_pkey" PRIMARY KEY (id);


--
-- Name: Operation Operation_pkey; Type: CONSTRAINT; Schema: public; Owner: prueba_user
--

ALTER TABLE ONLY public."Operation"
    ADD CONSTRAINT "Operation_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: prueba_user
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: Contact_email_key; Type: INDEX; Schema: prueba; Owner: prueba_user
--

CREATE UNIQUE INDEX "Contact_email_key" ON prueba."Contact" USING btree (email);


--
-- Name: Operation_contactId_createdAt_idx; Type: INDEX; Schema: prueba; Owner: prueba_user
--

CREATE INDEX "Operation_contactId_createdAt_idx" ON prueba."Operation" USING btree ("contactId", "createdAt");


--
-- Name: Contact_email_key; Type: INDEX; Schema: public; Owner: prueba_user
--

CREATE UNIQUE INDEX "Contact_email_key" ON public."Contact" USING btree (email);


--
-- Name: Operation_contactId_createdAt_idx; Type: INDEX; Schema: public; Owner: prueba_user
--

CREATE INDEX "Operation_contactId_createdAt_idx" ON public."Operation" USING btree ("contactId", "createdAt");


--
-- Name: Operation Operation_contactId_fkey; Type: FK CONSTRAINT; Schema: prueba; Owner: prueba_user
--

ALTER TABLE ONLY prueba."Operation"
    ADD CONSTRAINT "Operation_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES prueba."Contact"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Operation Operation_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: prueba_user
--

ALTER TABLE ONLY public."Operation"
    ADD CONSTRAINT "Operation_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public."Contact"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO prueba_user;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO prueba_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO prueba_user;


--
-- PostgreSQL database dump complete
--

\unrestrict jd2Dhl7OAJL9GBrTZubyuCuI1dgUVzao0oFjIPFDandm7kHdhgEZYD1GvM9LyUz

